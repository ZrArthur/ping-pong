var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["9f1006a5-dba8-4565-9336-573ecff7c607"],"propsByKey":{"9f1006a5-dba8-4565-9336-573ecff7c607":{"name":"bolinha1","sourceUrl":null,"frameSize":{"x":16,"y":16},"frameCount":1,"looping":true,"frameDelay":12,"version":".I1uIRI_PfhUVCkbHYumqw2ncYuW6pPQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":16,"y":16},"rootRelativePath":"assets/9f1006a5-dba8-4565-9336-573ecff7c607.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var raquete1 = createSprite(390, 200, 10, 90);
var raquete2 = createSprite(10, 200, 10, 90);
var bolinha = createSprite(200, 200, 10, 10);
bolinha.velocityX = 0 ;
bolinha.velocityY = 0;
createEdgeSprites();
createEdgeSprites();
function draw() 
{
  background("white");
  
  if (bolinha.isTouching(raquete1)  || bolinha.isTouching(raquete2))
  {
   playSound("assets/category_objects/click.mp3", false);
  }
  
  raquete1.shapeColor = "red";
  raquete2.shapeColor = "blue";
  bolinha.shapeColor = "lightgreen";
  bolinha.setAnimation("bolinha1");
  bolinha.rotation;
  bolinha.rotationSpeed = 16;
  bolinha.bounceOff(topEdge);
  bolinha.bounceOff(bottomEdge);
  bolinha.bounceOff(raquete1);
  bolinha.bounceOff(raquete2);

  raquete1.y=World.mouseY 
  if (raquete1.y<=45){
    raquete1.y=45
  }
  if (raquete1.y>=355){
    raquete1.y=355
  }
  raquete2.y=bolinha.y
  if (raquete2.y<=45){
    raquete2.y=45
  }
  if (raquete2.y>=355){
    raquete2.y=355
  }
   
  if(keyDown("space"))
  {
     bolinha.velocityX=2;
     bolinha.velocityY=3;
  }
 
  for ( num = 0; num <= 400; num = num + 20)
  
  {
    line (200, num, 200, num +10)
  }
 
 
 
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
